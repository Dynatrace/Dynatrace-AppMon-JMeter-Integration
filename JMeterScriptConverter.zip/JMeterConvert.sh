#!/bin/sh

java -jar scriptConverter.jar $*