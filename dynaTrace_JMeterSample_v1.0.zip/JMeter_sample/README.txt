Thank you for downloading this software from the dynaTrace Community Portal.

For instructions on installation and usage of this software and for access to
updates, please visit the dynaTrace Community Portal at http://community.dynatrace.com.

Feel free to improve this software.  If you do, please submit it to us so that we can
make it available to others in the dynaTrace Community.

We hope you find the dynaTrace Community Portal a valuable resource and we really
encourage you to check back often as new content is added all the time.  We hope you
will submit your content too as it is a great place to share ideas and tools.

Thanks!
dynaTrace software